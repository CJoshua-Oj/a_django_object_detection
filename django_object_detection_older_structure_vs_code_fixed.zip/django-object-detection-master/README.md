# Django YOLOv5 Object Detection - Older Structure Fixed for VS Code

This ZIP keeps the older uploaded project structure and repairs/arranges the files so it can run in VS Code.

## Run in VS Code

1. Extract the ZIP file.
2. Open the folder that contains `manage.py` in VS Code.
3. Open terminal in VS Code.
4. Run these commands:

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

5. Open:

```text
http://127.0.0.1:8000/
```

## Pages

- Live webcam detection: `http://127.0.0.1:8000/`
- Image upload detection: `http://127.0.0.1:8000/image-detection/`

## Important

- First run needs internet because YOLOv5 downloads the model.
- Allow camera permission if asked.
- Close Zoom, Teams, OBS, or any app using the webcam.
